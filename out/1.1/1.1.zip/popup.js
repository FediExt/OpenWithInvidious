document.getElementById("settings").addEventListener("click", function() {
    chrome.runtime.openOptionsPage();
});